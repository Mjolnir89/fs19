# FS19_GlobalCompany

## WICHTIG: Lade dir NUR Relase-Versionen runter!

1) Klicke auf "release" oder folge diesem Link: https://github.com/Ls-Modcompany/FS19_GlobalCompany/releases
2) Dort gibt es nun Versionen, die spielbereit sind.

-> Wenn das komplette Repository geladen wird, kann nicht sichergestellt werden, dass der Mod ohne Probleme funktionert!

3) Wollt Ihr dann z.B. die Version 1.1.1.0, dann kann dort der Bereich 'Asset' aufgeklappt werden. Dort dann auf 'Source Code (zip)' klicken.
4) Die geladene ZIP-Datei entpacken. 
5) Dort befindet sich ein weiteren Ordner. Der Inhalt von diesem Ordner dann wieder als ZIP-Datei mit dem Titel 'FS19_GlobalCompany' packen (D.h. auf der ersten Ebene muss sich dann die modDesc.xml befinden).
6) Die gepackte ZIP kann nun in den Modordner geschoben werden


# Bug melden

Fehler können entweder unter Issues gemeldet werden oder bei uns im Forum: https://ls-modcompany.com/forum/board/119-globalcompany/
